export type Confidence = "high" | "medium" | "low";

export interface FoodQueryResult {
  id: string;
  originalQuery: string;
  foodId: number | null;
  name: string;
  quantityText: string;
  grams: number;
  calories: number;
  calorieMin: number;
  calorieMax: number;
  confidence: Confidence;
  source: "cloud";
  createdAt: number;
}

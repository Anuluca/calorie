<script setup lang="ts">
import { computed } from "vue";
import { IonContent, IonPage } from "@ionic/vue";

const hasCloudEndpoint = computed(() => {
  const endpoint = String(import.meta.env.VITE_API_BASE_URL ?? "");
  return Boolean(endpoint && !endpoint.includes("example.workers.dev"));
});
</script>

<template>
  <ion-page>
    <ion-content :fullscreen="true" class="app-content">
      <main class="page-shell">
        <header class="title-row">
          <h1>设置</h1>
        </header>

        <section class="settings-group">
          <div class="setting-row">
            <div>
              <strong>智能查询</strong>
              <span>{{ hasCloudEndpoint ? "已配置" : "等待部署" }}</span>
            </div>
          </div>

          <div class="setting-row static-row">
            <div>
              <strong>查询方式</strong>
              <span>完全由 AI 估算</span>
            </div>
          </div>

          <div class="setting-row static-row">
            <div>
              <strong>数据存储</strong>
              <span>仅保存在本机</span>
            </div>
          </div>
        </section>

        <p class="legal-note">
          热量会受重量、配方和烹饪方式影响，结果仅供饮食记录参考。
        </p>
      </main>
    </ion-content>
  </ion-page>
</template>

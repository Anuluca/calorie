package com.example.calorieai;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

<script setup lang="ts">
import { onMounted, ref } from "vue";
import {
  IonContent,
  IonIcon,
  IonPage,
  IonSpinner
} from "@ionic/vue";
import { arrowUp, sparkles } from "ionicons/icons";
import { queryFood } from "@/services/query-service";
import { useHistoryStore } from "@/stores/history";
import type { FoodQueryResult } from "@/types";
import ResultCard from "@/components/ResultCard.vue";

const history = useHistoryStore();
const query = ref("");
const result = ref<FoodQueryResult | null>(null);
const loading = ref(false);
const error = ref("");
const quickQueries = ["两个水煮鸡蛋", "一碗牛肉面", "一杯拿铁"];

onMounted(() => history.load());

async function submit(text = query.value) {
  const value = text.trim();
  if (!value || loading.value) return;

  query.value = value;
  loading.value = true;
  error.value = "";

  try {
    const nextResult = await queryFood(value);
    result.value = nextResult;
    await history.add(nextResult);
  } catch (cause) {
    result.value = null;
    error.value = cause instanceof Error ? cause.message : "查询失败";
  } finally {
    loading.value = false;
  }
}
</script>

<template>
  <ion-page>
    <ion-content :fullscreen="true" class="app-content">
      <main class="page-shell search-page">
        <header class="page-header">
          <div class="app-mark" aria-hidden="true">
            <ion-icon :icon="sparkles" />
          </div>
          <h1>热量快查</h1>
        </header>

        <form class="search-panel" @submit.prevent="submit()">
          <label class="sr-only" for="food-query">食物名称和份量</label>
          <textarea
            id="food-query"
            v-model="query"
            rows="2"
            maxlength="200"
            enterkeyhint="search"
            placeholder="例如：两个水煮鸡蛋"
            @keydown.enter.exact.prevent="submit()"
          />
          <button
            class="submit-button"
            type="submit"
            :disabled="!query.trim() || loading"
            aria-label="查询热量"
          >
            <ion-spinner v-if="loading" name="crescent" />
            <ion-icon v-else :icon="arrowUp" aria-hidden="true" />
          </button>
        </form>

        <div class="quick-row" aria-label="快捷查询">
          <button
            v-for="item in quickQueries"
            :key="item"
            type="button"
            class="quick-chip"
            @click="submit(item)"
          >
            {{ item }}
          </button>
        </div>

        <p v-if="error" class="error-message" role="alert">{{ error }}</p>

        <transition name="result">
          <result-card v-if="result" :result="result" />
        </transition>

        <div v-if="!result && !error" class="empty-state">
          <div class="empty-ring" aria-hidden="true">
            <span />
          </div>
          <p>输入食物和份量</p>
        </div>
      </main>
    </ion-content>
  </ion-page>
</template>

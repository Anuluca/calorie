<script setup lang="ts">
import { onMounted } from "vue";
import { IonContent, IonIcon, IonPage } from "@ionic/vue";
import { timeOutline } from "ionicons/icons";
import HistoryCard from "@/components/HistoryCard.vue";
import { useHistoryStore } from "@/stores/history";

const history = useHistoryStore();

onMounted(() => history.load());
</script>

<template>
  <ion-page>
    <ion-content :fullscreen="true" class="app-content">
      <main class="page-shell">
        <header class="title-row">
          <h1>历史</h1>
          <button
            v-if="history.count"
            type="button"
            class="text-button"
            @click="history.clear"
          >
            清空
          </button>
        </header>

        <div v-if="history.count" class="history-list">
          <history-card
            v-for="item in history.items"
            :key="item.id"
            :item="item"
          />
        </div>

        <div v-else class="empty-state history-empty">
          <div class="empty-icon" aria-hidden="true">
            <ion-icon :icon="timeOutline" />
          </div>
          <p>还没有记录</p>
        </div>
      </main>
    </ion-content>
  </ion-page>
</template>

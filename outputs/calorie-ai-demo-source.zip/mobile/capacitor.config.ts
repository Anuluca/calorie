import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.example.calorieai",
  appName: "热量快查",
  webDir: "dist",
  backgroundColor: "#f4f5f7",
  ios: {
    contentInset: "automatic",
    preferredContentMode: "mobile"
  },
  android: {
    backgroundColor: "#f4f5f7",
    allowMixedContent: false
  }
};

export default config;

